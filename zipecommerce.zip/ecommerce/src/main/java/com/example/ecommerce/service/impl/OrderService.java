package com.example.ecommerce.service;

import com.example.ecommerce.model.Order; // Order model sınıfını import edin
import com.example.ecommerce.model.Customer; // Müşteri bilgisini kullanmak için
import com.example.ecommerce.model.Cart; // Sepetten sipariş oluşturmak için
import java.util.List;
import java.util.Optional;

public interface OrderService {
    List<Order> getAllOrders();
    Optional<Order> getOrderById(Long id);
    Order saveOrder(Order order);
    void deleteOrder(Long id);
    List<Order> getOrdersByCustomer(Customer customer); // Müşteriye ait siparişleri getirme
    Order placeOrderFromCart(Long customerId, Long cartId); // Sepetten sipariş oluşturma (müşteri ve sepet ID'leri ile)
    // İhtiyaç duyulacak diğer metodlar (örn: sipariş durumunu güncelleme, sipariş iptali vb.)
}