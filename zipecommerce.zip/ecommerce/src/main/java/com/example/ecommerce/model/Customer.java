package com.example.ecommerce.model;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;
import java.util.List; // Sipariş listesi için
import java.util.ArrayList; // Listeyi başlatmak için

@Entity
@Table(name = "customers")
public class Customer extends BaseEntity {

    @Column(nullable = false)
    private String firstName;

    @Column(nullable = false)
    private String lastName;

    @Column(nullable = false, unique = true) // E-posta adresi benzersiz olmalı
    private String email;

    @Column(nullable = false) // Güvenlik için şifre hash'lenmiş olarak saklanmalı
    private String password; // Not: Gerçek bir uygulamada şifreler şifrelenmeli ve hash'lenmeli!

    // Bir müşterinin bir sepeti vardır (OneToOne ilişki)
    // mappedBy="customer" Cart sınıfındaki 'customer' alanına işaret eder
    // CascadeType.ALL: Müşteri silindiğinde sepeti de silinir
    // orphanRemoval=true: Sepet, müşterisiz kalırsa silinir
    @OneToOne(mappedBy = "customer", cascade = CascadeType.ALL, orphanRemoval = true)
    private Cart cart;

    // Bir müşterinin birden fazla siparişi olabilir (OneToMany ilişki)
    // mappedBy="customer" Order sınıfındaki 'customer' alanına işaret eder
    // CascadeType.ALL: Müşteri silindiğinde siparişleri de silinir (Dikkatli kullanılmalı!)
    // orphanRemoval=true: Sipariş, müşterisiz kalırsa silinir
    @OneToMany(mappedBy = "customer", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Order> orders = new ArrayList<>(); // Yeni sipariş eklemek için boş liste

    // --- Constructors ---
    public Customer() {
    }

    public Customer(String firstName, String lastName, String email, String password) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.email = email;
        this.password = password;
    }

    // --- Getter and Setter Metodları ---
    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public Cart getCart() {
        return cart;
    }

    public void setCart(Cart cart) {
        this.cart = cart;
        // Sepeti müşteriye bağlarken, sepetin de müşteriyi bildiğinden emin olun
        if (cart != null && cart.getCustomer() != this) {
            cart.setCustomer(this);
        }
    }

    public List<Order> getOrders() {
        return orders;
    }

    public void setOrders(List<Order> orders) {
        this.orders = orders;
    }

    // Yardımcı metodlar (isteğe bağlı ama ilişkileri yönetmek için faydalı)
    public void addOrder(Order order) {
        orders.add(order);
        order.setCustomer(this);
    }

    public void removeOrder(Order order) {
        orders.remove(order);
        order.setCustomer(null);
    }
}