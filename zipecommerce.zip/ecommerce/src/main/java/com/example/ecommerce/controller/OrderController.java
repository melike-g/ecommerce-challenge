package com.example.ecommerce.controller;

import com.example.ecommerce.model.Order; // Order modelini import edin
import com.example.ecommerce.model.Customer; // Müşteri modelini kullanmak için
import com.example.ecommerce.service.OrderService; // OrderService'i import edin
import com.example.ecommerce.service.CustomerService; // CustomerService'i import edin

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/orders") // Bu controller'daki tüm endpoint'lerin başlangıç yolu
public class OrderController {

    private final OrderService orderService;
    private final CustomerService customerService; // Müşteriye göre siparişleri bulmak için

    @Autowired
    public OrderController(OrderService orderService, CustomerService customerService) {
        this.orderService = orderService;
        this.customerService = customerService;
    }

    // Tüm siparişleri getiren GET endpoint'i (Yönetim veya genel liste için)
    @GetMapping
    public ResponseEntity<List<Order>> getAllOrders() {
        List<Order> orders = orderService.getAllOrders();
        return new ResponseEntity<>(orders, HttpStatus.OK);
    }

    // Belirli bir ID'ye sahip siparişi getiren GET endpoint'i
    @GetMapping("/{id}")
    public ResponseEntity<Order> getOrderById(@PathVariable Long id) {
        return orderService.getOrderById(id)
                .map(order -> new ResponseEntity<>(order, HttpStatus.OK))
                .orElseGet(() -> new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    // Müşteriye ait tüm siparişleri getiren GET endpoint'i
    @GetMapping("/customer/{customerId}")
    public ResponseEntity<List<Order>> getOrdersByCustomer(@PathVariable Long customerId) {
        Optional<Customer> customerOptional = customerService.getCustomerById(customerId);
        if (customerOptional.isPresent()) {
            List<Order> orders = orderService.getOrdersByCustomer(customerOptional.get());
            return new ResponseEntity<>(orders, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND); // Müşteri bulunamadı
        }
    }

    // Yeni sipariş oluşturan POST endpoint'i (Genellikle doğrudan sepetten sipariş verilir)
    // Eğer manuel olarak sipariş oluşturulacaksa bu kullanılabilir.
    @PostMapping
    public ResponseEntity<Order> createOrder(@RequestBody Order order) {
        Order savedOrder = orderService.saveOrder(order);
        return new ResponseEntity<>(savedOrder, HttpStatus.CREATED);
    }

    // Sepetten sipariş oluşturan POST endpoint'i
    // HTTP POST isteği: /api/orders/placeOrder?customerId=1&cartId=1
    @PostMapping("/placeOrder")
    public ResponseEntity<Order> placeOrderFromCart(
            @RequestParam Long customerId,
            @RequestParam Long cartId) {
        try {
            Order newOrder = orderService.placeOrderFromCart(customerId, cartId);
            return new ResponseEntity<>(newOrder, HttpStatus.CREATED); // 201 Created
        } catch (RuntimeException e) {
            // Hata mesajını daha detaylı döndürebilirsiniz (örn: sepet boş, müşteri/sepet bulunamadı)
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST); // Örneğin 400 Bad Request
        }
    }

    // Mevcut siparişi güncelleyen PUT endpoint'i (örn: durum güncelleme)
    @PutMapping("/{id}")
    public ResponseEntity<Order> updateOrder(@PathVariable Long id, @RequestBody Order orderDetails) {
        Optional<Order> orderOptional = orderService.getOrderById(id);
        if (orderOptional.isPresent()) {
            Order existingOrder = orderOptional.get();
            // Sadece güncellenmesine izin verilen alanları güncelleyin (örn: status)
            existingOrder.setStatus(orderDetails.getStatus());
            // existingOrder.setShippingAddress(orderDetails.getShippingAddress()); // Eğer Order entity'de bu varsa

            Order updatedOrder = orderService.saveOrder(existingOrder);
            return new ResponseEntity<>(updatedOrder, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    // Belirli bir ID'ye sahip siparişi silen DELETE endpoint'i
    @DeleteMapping("/{id}")
    public ResponseEntity<HttpStatus> deleteOrder(@PathVariable Long id) {
        orderService.deleteOrder(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
}