package com.example.ecommerce.repository;

import com.example.ecommerce.model.OrderItem; // İlgili Model sınıfını import edin
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface OrderItemRepository extends JpaRepository<OrderItem, Long> {
    // JpaRepository, OrderItem varlığı için temel CRUD operasyonlarını sağlar.
    // İhtiyaç duyarsanız buraya özel sorgu metodları ekleyebilirsiniz (örn: List<OrderItem> findByOrderId(Long orderId);)
}