package com.example.ecommerce.model;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "carts")
public class Cart extends BaseEntity {

    // Bir sepetin bir müşterisi vardır (OneToOne ilişki)
    // JoinColumn: Cart tablosunda 'customer_id' adında bir sütun oluşturulur ve Customer tablosunun birincil anahtarına bağlanır.
    // nullable = false: Bu, her sepetin bir müşteriye bağlı olması gerektiğini belirtir.
    @OneToOne
    @JoinColumn(name = "customer_id", nullable = false)
    private Customer customer;

    @Column(nullable = false)
    private Double totalPrice = 0.0; // Sepetin toplam fiyatı, başlangıçta 0.0 olarak ayarlanır.

    // Bir sepette birden fazla CartItem (sepet kalemi) olabilir (OneToMany ilişki)
    // mappedBy="cart": CartItem sınıfındaki 'cart' alanına işaret eder.
    // CascadeType.ALL: Sepetle birlikte CartItem'ların da kaydedilmesi/silinmesi gibi işlemleri tetikler.
    // orphanRemoval=true: Sepet silinirse veya bir CartItem sepetten çıkarılırsa, CartItem da silinir.
    @OneToMany(mappedBy = "cart", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<CartItem> cartItems = new ArrayList<>(); // Sepetteki ürün kalemleri

    // --- Constructors ---
    public Cart() {
    }

    public Cart(Customer customer) {
        this.customer = customer;
        this.totalPrice = 0.0;
    }

    // --- Getter and Setter Metodları ---
    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    public Double getTotalPrice() {
        return totalPrice;
    }

    public void setTotalPrice(Double totalPrice) {
        this.totalPrice = totalPrice;
    }

    public List<CartItem> getCartItems() {
        return cartItems;
    }

    public void setCartItems(List<CartItem> cartItems) {
        this.cartItems = cartItems;
    }

    // --- Yardımcı Metodlar --- (Sepete ürün ekleme/çıkarma ve toplam fiyatı güncelleme için)

    public void addCartItem(CartItem cartItem) {
        cartItems.add(cartItem);
        cartItem.setCart(this); // CartItem'ın da hangi sepete ait olduğunu bilmesini sağla
        calculateTotalPrice(); // Ürün eklendiğinde toplam fiyatı güncelle
    }

    public void removeCartItem(CartItem cartItem) {
        cartItems.remove(cartItem);
        cartItem.setCart(null); // CartItem'ın sepetle ilişkisini kes
        calculateTotalPrice(); // Ürün çıkarıldığında toplam fiyatı güncelle
    }

    // Toplam fiyatı hesaplama metodu
    public void calculateTotalPrice() {
        this.totalPrice = cartItems.stream()
                .mapToDouble(item -> item.getProduct().getPrice() * item.getQuantity())
                .sum();
    }
}