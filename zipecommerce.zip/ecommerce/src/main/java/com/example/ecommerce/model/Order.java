package com.example.ecommerce.model;

import javax.persistence.*;
import java.time.LocalDateTime;
import java.util.HashSet;
import java.util.Set;

@Entity
@Table(name = "orders") // "Order" SQL keyword olabileceği için "orders" kullanmak daha güvenli
public class Order {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "customer_id", nullable = false)
    private Customer customer;

    private LocalDateTime orderDate;

    private double totalPrice;

    private String status; // Örneğin: PENDING, PROCESSING, SHIPPED, DELIVERED, CANCELED

    // OrderItem'lar ile ilişki
    // CascadeType.ALL: Order kaydedildiğinde OrderItem'lar da kaydedilir, güncellendiğinde güncellenir, silindiğinde silinir.
    // orphanRemoval = true: Bir OrderItem, Order'ın orderItems setinden çıkarıldığında otomatik olarak silinir.
    @OneToMany(mappedBy = "order", cascade = CascadeType.ALL, orphanRemoval = true, fetch = FetchType.LAZY)
    private Set<OrderItem> orderItems = new HashSet<>();

    // Constructor'lar, Getter'lar ve Setter'lar

    public Order() {
    }

    public Order(Customer customer, LocalDateTime orderDate, double totalPrice, String status) {
        this.customer = customer;
        this.orderDate = orderDate;
        this.totalPrice = totalPrice;
        this.status = status;
    }

    // Getter and Setter for id
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    // Getter and Setter for customer
    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    // Getter and Setter for orderDate
    public LocalDateTime getOrderDate() {
        return orderDate;
    }

    public void setOrderDate(LocalDateTime orderDate) {
        this.orderDate = orderDate;
    }

    // Getter and Setter for totalPrice
    public double getTotalPrice() {
        return totalPrice;
    }

    public void setTotalPrice(double totalPrice) {
        this.totalPrice = totalPrice;
    }

    // Getter and Setter for status
    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    // Getter for orderItems
    public Set<OrderItem> getOrderItems() {
        return orderItems;
    }

    // Setter for orderItems (genellikle add/remove metodları tercih edilir)
    public void setOrderItems(Set<OrderItem> orderItems) {
        this.orderItems = orderItems;
    }

    // Helper methods to manage orderItems relationship
    public void addOrderItem(OrderItem orderItem) {
        orderItems.add(orderItem);
        orderItem.setOrder(this); // OrderItem'ın order referansını ayarla
    }

    public void removeOrderItem(OrderItem orderItem) {
        orderItems.remove(orderItem);
        orderItem.setOrder(null); // OrderItem'ın order referansını kaldır
    }

    @Override
    public String toString() {
        return "Order{" +
                "id=" + id +
                ", customer=" + (customer != null ? customer.getId() : "null") +
                ", orderDate=" + orderDate +
                ", totalPrice=" + totalPrice +
                ", status='" + status + '\'' +
                ", orderItemsCount=" + orderItems.size() +
                '}';
    }
}