package com.example.ecommerce.service.impl;

import com.example.ecommerce.model.Customer; // Customer model sınıfını import edin
import com.example.ecommerce.repository.CustomerRepository; // CustomerRepository'yi import edin
import com.example.ecommerce.service.CustomerService; // CustomerService arayüzünü import edin
import org.springframework.stereotype.Service; // @Service anotasyonu için
import org.springframework.beans.factory.annotation.Autowired; // @Autowired anotasyonu için

import java.util.List;
import java.util.Optional;

@Service // Spring'e bu sınıfın bir servis katmanı bileşeni olduğunu belirtir
public class CustomerServiceImpl implements CustomerService { // CustomerService arayüzünü implement eder

    private final CustomerRepository customerRepository; // CustomerRepository'yi enjekte edeceğiz

    // Constructor Injection: Bağımlılıkları enjekte etmenin en iyi yolu
    @Autowired // Spring, CustomerRepository'nin bir örneğini otomatik olarak buraya enjekte eder
    public CustomerServiceImpl(CustomerRepository customerRepository) {
        this.customerRepository = customerRepository;
    }

    @Override // Arayüz metodunu implement ettiğimizi belirtir
    public List<Customer> getAllCustomers() {
        return customerRepository.findAll(); // Tüm müşterileri Repository'den getir
    }

    @Override
    public Optional<Customer> getCustomerById(Long id) {
        return customerRepository.findById(id); // ID'ye göre müşteriyi Repository'den getir
    }

    @Override
    public Customer saveCustomer(Customer customer) {
        return customerRepository.save(customer); // Müşteriyi Repository aracılığıyla kaydet/güncelle
    }

    @Override
    public void deleteCustomer(Long id) {
        customerRepository.deleteById(id); // ID'ye göre müşteriyi Repository aracılığıyla sil
    }

    // İhtiyaç duyacağınız diğer metodlar (örn: email ile müşteri bulma vb.) buraya eklenecek
    // @Override
    // public Customer findByEmail(String email) { ... }
}