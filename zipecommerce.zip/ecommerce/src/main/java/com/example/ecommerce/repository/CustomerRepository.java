package com.example.ecommerce.repository;

import com.example.ecommerce.model.Customer; // İlgili Model sınıfını import edin
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface CustomerRepository extends JpaRepository<Customer, Long> {
    // JpaRepository, Customer varlığı için temel CRUD operasyonlarını sağlar.
    // İhtiyaç duyarsanız buraya özel sorgu metodları ekleyebilirsiniz (örn: Customer findByEmail(String email);)
}