package com.example.ecommerce.service.impl;

import com.example.ecommerce.model.Order;
import com.example.ecommerce.model.OrderItem;
import com.example.ecommerce.model.Cart;
import com.example.ecommerce.model.CartItem;
import com.example.ecommerce.model.Customer;
import com.example.ecommerce.repository.OrderRepository;
import com.example.ecommerce.repository.OrderItemRepository; // Order tarafından cascade edilmiyorsa gerekli olabilir, genellikle edilmeli
import com.example.ecommerce.repository.CartRepository;
import com.example.ecommerce.repository.CustomerRepository;
import com.example.ecommerce.service.OrderService;
import com.example.ecommerce.service.CartService; // Sepet hizmetini kullanmak için enjekte ediyoruz
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import javax.transaction.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.Set; // CartItem'lar Set olarak tanımlandıysa

@Service
public class OrderServiceImpl implements OrderService {

    private final OrderRepository orderRepository;
    private final OrderItemRepository orderItemRepository; // Cascade varsa zorunlu değil ama bulunmasında fayda var
    private final CartRepository cartRepository;
    private final CustomerRepository customerRepository;
    private final CartService cartService; // Sepet işlemlerini yönetmek için CartService'i enjekte ediyoruz

    @Autowired
    public OrderServiceImpl(OrderRepository orderRepository, OrderItemRepository orderItemRepository,
                            CartRepository cartRepository, CustomerRepository customerRepository,
                            CartService cartService) { // CartService de constructor'a eklendi
        this.orderRepository = orderRepository;
        this.orderItemRepository = orderItemRepository;
        this.cartRepository = cartRepository;
        this.customerRepository = customerRepository;
        this.cartService = cartService; // Enjekte edilen servis atanıyor
    }

    @Override
    public List<Order> getAllOrders() {
        return orderRepository.findAll();
    }

    @Override
    public Optional<Order> getOrderById(Long id) {
        return orderRepository.findById(id);
    }

    @Override
    public Order saveOrder(Order order) {
        // Yeni bir sipariş kaydedilirken tarih ve durumu otomatik set edebilirsiniz
        if (order.getId() == null) { // Eğer yeni bir siparişse
            order.setOrderDate(LocalDateTime.now());
            order.setStatus("PENDING"); // Varsayılan durum
        }
        return orderRepository.save(order);
    }

    @Override
    public void deleteOrder(Long id) {
        orderRepository.deleteById(id);
    }

    @Override
    public List<Order> getOrdersByCustomer(Customer customer) {
        // Bu metodun çalışması için OrderRepository'de 'List<Order> findByCustomer(Customer customer);'
        // veya 'List<Order> findByCustomerId(Long customerId);' gibi bir metot tanımlanmış olmalıdır.
        return orderRepository.findByCustomer(customer);
    }

    @Override
    @Transactional // Tüm işlem başarılı olmalı veya hiçbiri olmamalı
    public Order placeOrderFromCart(Long customerId, Long cartId) {
        Customer customer = customerRepository.findById(customerId)
                .orElseThrow(() -> new RuntimeException("Customer not found with id: " + customerId));
        Cart cart = cartRepository.findById(cartId)
                .orElseThrow(() -> new RuntimeException("Cart not found with id: " + cartId));

        if (cart.getCartItems().isEmpty()) {
            throw new RuntimeException("Cannot place order from an empty cart.");
        }

        // Yeni bir sipariş oluştur
        Order order = new Order();
        order.setCustomer(customer);
        order.setOrderDate(LocalDateTime.now());
        order.setStatus("PENDING"); // Sipariş başlangıç durumu (örn: PENDING, PROCESSING, COMPLETED)
        order.setTotalPrice(calculateOrderTotalPrice(cart.getCartItems()));

        // Sepet öğelerini sipariş öğelerine dönüştür
        for (CartItem cartItem : cart.getCartItems()) {
            OrderItem orderItem = new OrderItem();
            // orderItem.setOrder(order); // addOrderItem metodu bunu halledecek
            orderItem.setProduct(cartItem.getProduct());
            orderItem.setQuantity(cartItem.getQuantity());
            orderItem.setPriceAtPurchase(cartItem.getPriceAtPurchase()); // Sepet öğesindeki fiyatı kullan
            order.addOrderItem(orderItem); // Order entity'nizde bu metot olmalı
        }

        // Siparişi kaydet (CascadeType.ALL sayesinde OrderItem'lar da otomatik kaydedilir)
        Order savedOrder = orderRepository.save(order);

        // Sipariş oluştuktan sonra sepeti boşaltma işlemini CartService üzerinden yapıyoruz
        // Bu metodun CartService'te ürün stoklarını geri ekleyerek çalıştığından emin olun.
        cartService.emptyCart(cartId);

        return savedOrder;
    }

    // Sipariş toplam fiyatını hesaplayan yardımcı metot
    private double calculateOrderTotalPrice(Set<CartItem> cartItems) {
        return cartItems.stream()
                .mapToDouble(item -> item.getQuantity() * item.getPriceAtPurchase())
                .sum();
    }
}