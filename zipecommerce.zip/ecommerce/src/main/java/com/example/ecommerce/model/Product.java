package com.example.ecommerce.model;

import jakarta.persistence.Entity; // Bu anotasyon, bu sınıfın bir JPA varlığı (entity) olduğunu ve veritabanında bir tabloya karşılık geleceğini belirtir.
import jakarta.persistence.Table; // Opsiyonel: Tablo adını belirtmek için
import jakarta.persistence.Column; // Opsiyonel: Sütun adını veya özelliklerini belirtmek için

// Product sınıfı BaseEntity'den miras alır, böylece id, createdDate ve lastModifiedDate gibi alanlara sahip olur.
@Entity // Bu anotasyon, JPA'ya bu sınıfın bir veritabanı tablosuna eşleneceğini söyler.
@Table(name = "products") // Opsiyonel: Veritabanındaki tablonun adını "products" olarak belirler. Belirtmezseniz sınıf adını kullanır.
public class Product extends BaseEntity {

    @Column(nullable = false) // Bu sütunun null olamayacağını belirtir
    private String name;

    @Column(length = 1000) // Açıklama alanının maksimum uzunluğunu belirler
    private String description;

    @Column(nullable = false)
    private Double price;

    @Column(nullable = false)
    private Integer stock; // Stok miktarı için alan

    // --- Constructor'lar (isteğe bağlı ama iyi bir pratik) ---
    public Product() {
    }

    public Product(String name, String description, Double price, Integer stock) {
        this.name = name;
        this.description = description;
        this.price = price;
        this.stock = stock;
    }

    // --- Getter ve Setter Metodları ---
    // (IntelliJ IDEA'da genellikle Alt + Insert tuşlarına basıp "Getter and Setter" seçerek otomatik oluşturabilirsiniz)

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Double getPrice() {
        return price;
    }

    public void setPrice(Double price) {
        this.price = price;
    }

    public Integer getStock() {
        return stock;
    }

    public void setStock(Integer stock) {
        this.stock = stock;
    }

    // İsteğe bağlı: toString, equals ve hashCode metodları
    @Override
    public String toString() {
        return "Product{" +
                "id=" + getId() + // BaseEntity'den gelen id'yi de dahil edebiliriz
                ", name='" + name + '\'' +
                ", description='" + description + '\'' +
                ", price=" + price +
                ", stock=" + stock +
                '}';
    }
}