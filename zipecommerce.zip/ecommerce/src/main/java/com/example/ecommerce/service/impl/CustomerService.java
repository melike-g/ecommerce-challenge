package com.example.ecommerce.service;

import com.example.ecommerce.model.Customer; // Customer model sınıfını import edin
import java.util.List;
import java.util.Optional;

public interface CustomerService { // Bir arayüz olduğunu belirtiyoruz
    List<Customer> getAllCustomers();
    Optional<Customer> getCustomerById(Long id);
    Customer saveCustomer(Customer customer);
    void deleteCustomer(Long id);
    // İhtiyaç duyulursa buraya Customer'a özel metodlar eklenebilir (örn: Customer findByEmail(String email);)
}