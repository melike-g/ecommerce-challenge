package com.example.ecommerce.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "cart_items")
public class CartItem extends BaseEntity { // CartItem da BaseEntity'den miras alabilir

    @ManyToOne // Birçok CartItem bir sepete (Cart) ait olabilir
    @JoinColumn(name = "cart_id", nullable = false) // 'cart_id' sütunu ile Cart tablosuna bağlanır
    private Cart cart;

    @ManyToOne // Birçok CartItem bir ürüne (Product) ait olabilir
    @JoinColumn(name = "product_id", nullable = false) // 'product_id' sütunu ile Product tablosuna bağlanır
    private Product product;

    @Column(nullable = false)
    private Integer quantity; // Ürünün sepetteki adedi

    // --- Constructors ---
    public CartItem() {
    }

    public CartItem(Cart cart, Product product, Integer quantity) {
        this.cart = cart;
        this.product = product;
        this.quantity = quantity;
    }

    // --- Getter and Setter Metodları ---
    public Cart getCart() {
        return cart;
    }

    public void setCart(Cart cart) {
        this.cart = cart;
    }

    public Product getProduct() {
        return product;
    }

    public void setProduct(Product product) {
        this.product = product;
    }

    public Integer getQuantity() {
        return quantity;
    }

    public void setQuantity(Integer quantity) {
        this.quantity = quantity;
    }
}