package com.example.ecommerce.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "order_items")
public class OrderItem extends BaseEntity { // OrderItem da BaseEntity'den miras alabilir

    @ManyToOne // Birçok OrderItem bir siparişe (Order) ait olabilir
    @JoinColumn(name = "order_id", nullable = false) // 'order_id' sütunu ile Order tablosuna bağlanır
    private Order order;

    @ManyToOne // Birçok OrderItem bir ürüne (Product) ait olabilir
    @JoinColumn(name = "product_id", nullable = false) // 'product_id' sütunu ile Product tablosuna bağlanır
    private Product product;

    @Column(nullable = false)
    private Integer quantity; // Ürünün siparişteki adedi

    @Column(nullable = false)
    private Double priceAtOrder; // Proje gereksinimi: Ürünün sipariş anındaki fiyatı

    // --- Constructors ---
    public OrderItem() {
    }

    public OrderItem(Order order, Product product, Integer quantity, Double priceAtOrder) {
        this.order = order;
        this.product = product;
        this.quantity = quantity;
        this.priceAtOrder = priceAtOrder;
    }

    // --- Getter and Setter Metodları ---
    public Order getOrder() {
        return order;
    }

    public void setOrder(Order order) {
        this.order = order;
    }

    public Product getProduct() {
        return product;
    }

    public void setProduct(Product product) {
        this.product = product;
    }

    public Integer getQuantity() {
        return quantity;
    }

    public void setQuantity(Integer quantity) {
        this.quantity = quantity;
    }

    public Double getPriceAtOrder() {
        return priceAtOrder;
    }

    public void setPriceAtOrder(Double priceAtOrder) {
        this.priceAtOrder = priceAtOrder;
    }
}