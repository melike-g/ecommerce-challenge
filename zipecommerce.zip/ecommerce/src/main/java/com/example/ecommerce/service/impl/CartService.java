package com.example.ecommerce.service;

import com.example.ecommerce.model.Cart; // Cart model sınıfını import edin
import com.example.ecommerce.model.Customer; // Customer model sınıfını import edin
import com.example.ecommerce.model.Product; // Product model sınıfını import edin
import java.util.List;
import java.util.Optional;

public interface CartService {
    List<Cart> getAllCarts();
    Optional<Cart> getCartById(Long id);
    Cart saveCart(Cart cart);
    void deleteCart(Long id);
    Cart getCartByCustomer(Customer customer); // Müşteriye ait sepeti getirme metodu
    Cart addProductToCart(Long cartId, Long productId, int quantity); // Sepete ürün ekleme
    Cart removeProductFromCart(Long cartId, Long productId); // Sepetten ürün çıkarma
    Cart emptyCart(Long cartId); // Sepeti boşaltma
}