package com.example.ecommerce.controller;

import com.example.ecommerce.model.Cart; // Cart modelini import edin
import com.example.ecommerce.model.Customer; // Müşteri modelini kullanmak için
import com.example.ecommerce.model.Product; // Ürün modelini kullanmak için
import com.example.ecommerce.service.CartService; // CartService'i import edin
import com.example.ecommerce.service.CustomerService; // CustomerService'i import edin
import com.example.ecommerce.service.ProductService; // ProductService'i import edin

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/carts") // Bu controller'daki tüm endpoint'lerin başlangıç yolu
public class CartController {

    private final CartService cartService;
    private final CustomerService customerService; // Müşteriye göre sepet bulmak için
    private final ProductService productService; // Sepete ürün eklemek için

    @Autowired
    public CartController(CartService cartService, CustomerService customerService, ProductService productService) {
        this.cartService = cartService;
        this.customerService = customerService;
        this.productService = productService;
    }

    // Tüm sepetleri getiren GET endpoint'i (Yönetim için)
    @GetMapping
    public ResponseEntity<List<Cart>> getAllCarts() {
        List<Cart> carts = cartService.getAllCarts();
        return new ResponseEntity<>(carts, HttpStatus.OK);
    }

    // Belirli bir ID'ye sahip sepeti getiren GET endpoint'i
    @GetMapping("/{id}")
    public ResponseEntity<Cart> getCartById(@PathVariable Long id) {
        return cartService.getCartById(id)
                .map(cart -> new ResponseEntity<>(cart, HttpStatus.OK))
                .orElseGet(() -> new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    // Müşteriye ait sepeti getiren GET endpoint'i
    @GetMapping("/customer/{customerId}")
    public ResponseEntity<Cart> getCartByCustomer(@PathVariable Long customerId) {
        Optional<Customer> customerOptional = customerService.getCustomerById(customerId);
        if (customerOptional.isPresent()) {
            // Varsayım: Cart entity'nizde Customer referansı var ve CartRepository'de findByCustomer metodu var.
            Cart cart = cartService.getCartByCustomer(customerOptional.get());
            if (cart != null) {
                return new ResponseEntity<>(cart, HttpStatus.OK);
            } else {
                // Müşterinin sepeti yoksa yeni bir boş sepet oluşturabilirsiniz
                // Ancak bu iş mantığı Service katmanında daha iyi yönetilir.
                return new ResponseEntity<>(HttpStatus.NOT_FOUND); // Veya HttpStatus.CREATED ile boş sepet döndür
            }
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND); // Müşteri bulunamadı
        }
    }

    // Yeni sepet oluşturan POST endpoint'i (Genellikle müşteri ilk kayıt olduğunda veya ilk ürün eklediğinde oluşturulur)
    @PostMapping
    public ResponseEntity<Cart> createCart(@RequestBody Cart cart) {
        // Eğer bir müşteriye ait yeni sepet oluşturuyorsanız, müşteri ID'si de gönderilmeli
        // Basit bir sepet oluşturma örneği:
        Cart savedCart = cartService.saveCart(cart);
        return new ResponseEntity<>(savedCart, HttpStatus.CREATED);
    }

    // Sepete ürün ekleyen POST endpoint'i
    // Örnek istek: POST /api/carts/{cartId}/add?productId=1&quantity=2
    @PostMapping("/{cartId}/add")
    public ResponseEntity<Cart> addProductToCart(
            @PathVariable Long cartId,
            @RequestParam Long productId,
            @RequestParam int quantity) {
        try {
            Cart updatedCart = cartService.addProductToCart(cartId, productId, quantity);
            return new ResponseEntity<>(updatedCart, HttpStatus.OK);
        } catch (RuntimeException e) {
            // Hata mesajını daha detaylı döndürebilirsiniz
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST); // Stok yok, sepet/ürün bulunamadı vb.
        }
    }

    // Sepetten ürün çıkaran DELETE endpoint'i
    // Örnek istek: DELETE /api/carts/{cartId}/remove?productId=1
    @DeleteMapping("/{cartId}/remove")
    public ResponseEntity<Cart> removeProductFromCart(
            @PathVariable Long cartId,
            @RequestParam Long productId) {
        try {
            Cart updatedCart = cartService.removeProductFromCart(cartId, productId);
            return new ResponseEntity<>(updatedCart, HttpStatus.OK);
        } catch (RuntimeException e) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND); // Sepet/ürün bulunamadı
        }
    }

    // Sepeti tamamen boşaltan DELETE endpoint'i
    // Örnek istek: DELETE /api/carts/{cartId}/empty
    @DeleteMapping("/{cartId}/empty")
    public ResponseEntity<Cart> emptyCart(@PathVariable Long cartId) {
        try {
            Cart emptiedCart = cartService.emptyCart(cartId);
            return new ResponseEntity<>(emptiedCart, HttpStatus.OK);
        } catch (RuntimeException e) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND); // Sepet bulunamadı
        }
    }

    // Belirli bir ID'ye sahip sepeti silen DELETE endpoint'i (Yönetim için)
    @DeleteMapping("/{id}")
    public ResponseEntity<HttpStatus> deleteCart(@PathVariable Long id) {
        cartService.deleteCart(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
}