package com.example.ecommerce.controller;

import com.example.ecommerce.model.Product; // Product modelini import edin
import com.example.ecommerce.service.ProductService; // ProductService'i import edin
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus; // HTTP durum kodları için
import org.springframework.http.ResponseEntity; // HTTP yanıtı için
import org.springframework.web.bind.annotation.*; // REST anotasyonları için

import java.util.List;
import java.util.Optional;

@RestController // Bu sınıfın bir REST Controller olduğunu belirtir
@RequestMapping("/api/products") // Bu controller'daki tüm endpoint'lerin başlangıç yolu
public class ProductController {

    private final ProductService productService; // ProductService'i enjekte edeceğiz

    @Autowired // Spring'e ProductService'i otomatik olarak enjekte etmesini söyler
    public ProductController(ProductService productService) {
        this.productService = productService;
    }

    // Tüm ürünleri getiren GET endpoint'i
    // HTTP GET isteği: /api/products
    @GetMapping
    public ResponseEntity<List<Product>> getAllProducts() {
        List<Product> products = productService.getAllProducts();
        return new ResponseEntity<>(products, HttpStatus.OK); // 200 OK ile ürün listesini döndür
    }

    // Belirli bir ID'ye sahip ürünü getiren GET endpoint'i
    // HTTP GET isteği: /api/products/{id}
    @GetMapping("/{id}")
    public ResponseEntity<Product> getProductById(@PathVariable Long id) {
        return productService.getProductById(id)
                .map(product -> new ResponseEntity<>(product, HttpStatus.OK)) // Bulunursa 200 OK
                .orElseGet(() -> new ResponseEntity<>(HttpStatus.NOT_FOUND)); // Bulunamazsa 404 Not Found
    }

    // Yeni ürün ekleyen POST endpoint'i
    // HTTP POST isteği: /api/products (Request Body'de Product JSON'ı ile)
    @PostMapping
    public ResponseEntity<Product> createProduct(@RequestBody Product product) {
        Product savedProduct = productService.saveProduct(product);
        return new ResponseEntity<>(savedProduct, HttpStatus.CREATED); // 201 Created ile yeni ürünü döndür
    }

    // Mevcut ürünü güncelleyen PUT endpoint'i
    // HTTP PUT isteği: /api/products/{id} (Request Body'de güncellenmiş Product JSON'ı ile)
    @PutMapping("/{id}")
    public ResponseEntity<Product> updateProduct(@PathVariable Long id, @RequestBody Product productDetails) {
        // Önce ürünü ID ile bul
        Optional<Product> productOptional = productService.getProductById(id);
        if (productOptional.isPresent()) {
            Product existingProduct = productOptional.get();
            // Mevcut ürünün alanlarını gelen detaylarla güncelle
            existingProduct.setName(productDetails.getName());
            existingProduct.setDescription(productDetails.getDescription());
            existingProduct.setPrice(productDetails.getPrice());
            existingProduct.setStock(productDetails.getStock());
            // Kategori, resim URL'si vb. diğer alanları da güncelleyebilirsiniz
            // existingProduct.setCategory(productDetails.getCategory());
            // existingProduct.setImageUrl(productDetails.getImageUrl());

            Product updatedProduct = productService.saveProduct(existingProduct); // Güncellenmiş ürünü kaydet
            return new ResponseEntity<>(updatedProduct, HttpStatus.OK); // 200 OK ile güncellenmiş ürünü döndür
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND); // Ürün bulunamazsa 404 Not Found
        }
    }

    // Belirli bir ID'ye sahip ürünü silen DELETE endpoint'i
    // HTTP DELETE isteği: /api/products/{id}
    @DeleteMapping("/{id}")
    public ResponseEntity<HttpStatus> deleteProduct(@PathVariable Long id) {
        productService.deleteProduct(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT); // 204 No Content (içerik yok) ile başarılı silme
    }
}