package com.example.ecommerce.model;

import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.MappedSuperclass;
import jakarta.persistence.PrePersist; // Kayıt öncesi otomatik tarih atama için
import jakarta.persistence.PreUpdate;  // Güncelleme öncesi otomatik tarih atama için
import java.time.LocalDateTime; // Java 8 ve sonrası için tarih-saat nesnesi

// @MappedSuperclass anotasyonu, bu sınıfın doğrudan bir veritabanı tablosu olmadığını,
// ancak diğer varlık sınıfları tarafından miras alınacağını ve ortak alanları barındıracağını belirtir.
@MappedSuperclass
public abstract class BaseEntity { // 'abstract' keyword'ü, bu sınıftan doğrudan nesne oluşturulmasını engeller,
    // sadece miras yoluyla kullanılabilir.

    @Id // Bu alanın birincil anahtar (Primary Key) olduğunu belirtir
    @GeneratedValue(strategy = GenerationType.IDENTITY) // Veritabanının ID'yi otomatik olarak artırmasını sağlar (MySQL, PostgreSQL için IDENTITY)
    private Long id; // Varlıkların benzersiz kimliği

    private LocalDateTime createdDate; // Kaydın oluşturulma tarihi
    private LocalDateTime lastModifiedDate; // Kaydın son güncellenme tarihi

    // @PrePersist anotasyonu, bir varlık veritabanına ilk kez kaydedilmeden hemen önce bu metodun çalıştırılmasını sağlar.
    @PrePersist
    protected void onCreate() {
        this.createdDate = LocalDateTime.now(); // Şimdiki zamanı oluşturulma tarihi olarak atar
    }

    // @PreUpdate anotasyonu, bir varlık veritabanında güncellenmeden hemen önce bu metodun çalıştırılmasını sağlar.
    @PreUpdate
    protected void onUpdate() {
        this.lastModifiedDate = LocalDateTime.now(); // Şimdiki zamanı son güncellenme tarihi olarak atar
    }

    // --- Getter ve Setter Metodları ---
    // (IntelliJ IDEA'da genellikle Alt + Insert tuşlarına basıp "Getter and Setter" seçerek otomatik oluşturabilirsiniz)

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public LocalDateTime getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(LocalDateTime createdDate) {
        this.createdDate = createdDate;
    }

    public LocalDateTime getLastModifiedDate() {
        return lastModifiedDate;
    }

    public void setLastModifiedDate(LocalDateTime lastModifiedDate) {
        this.lastModifiedDate = lastModifiedDate;
    }
}