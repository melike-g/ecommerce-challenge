package com.example.ecommerce.service.impl;

import com.example.ecommerce.model.Cart; // Cart model sınıfını import edin
import com.example.ecommerce.model.Customer; // Customer model sınıfını import edin
import com.example.ecommerce.model.Product; // Product model sınıfını import edin
import com.example.ecommerce.repository.CartRepository; // CartRepository'yi import edin
import com.example.ecommerce.repository.CustomerRepository; // CustomerRepository'yi import edin (opsiyonel)
import com.example.ecommerce.repository.ProductRepository; // ProductRepository'yi import edin (opsiyonel)
import com.example.ecommerce.service.CartService; // CartService arayüzünü import edin
import org.springframework.stereotype.Service; // @Service anotasyonu için
import org.springframework.beans.factory.annotation.Autowired; // @Autowired anotasyonu için

import java.util.List;
import java.util.Optional;
import javax.transaction.Transactional; // Sepet işlemleri için gerekli olabilir

@Service // Spring'e bu sınıfın bir servis katmanı bileşeni olduğunu belirtir
public class CartServiceImpl implements CartService { // CartService arayüzünü implement eder

    private final CartRepository cartRepository;
    private final ProductRepository productRepository; // Sepete ürün eklemek için
    private final CustomerRepository customerRepository; // Müşteriye göre sepet bulmak için (eğer Cart'ta Customer ID yoksa)

    // Constructor Injection
    @Autowired
    public CartServiceImpl(CartRepository cartRepository, ProductRepository productRepository, CustomerRepository customerRepository) {
        this.cartRepository = cartRepository;
        this.productRepository = productRepository;
        this.customerRepository = customerRepository;
    }

    @Override
    public List<Cart> getAllCarts() {
        return cartRepository.findAll();
    }

    @Override
    public Optional<Cart> getCartById(Long id) {
        return cartRepository.findById(id);
    }

    @Override
    public Cart saveCart(Cart cart) {
        // Sepet kaydedilirken toplam fiyatı da güncelleyebilirsiniz
        // Bu kısımda Cart'ın içeriğine göre totalPrice hesaplaması yapılabilir
        // cart.setTotalPrice(calculateTotalPrice(cart));
        return cartRepository.save(cart);
    }

    @Override
    public void deleteCart(Long id) {
        cartRepository.deleteById(id);
    }

    @Override
    public Cart getCartByCustomer(Customer customer) {
        // Eğer Cart nesnesi doğrudan Customer referansını tutuyorsa bu metot kullanılabilir.
        // Aksi halde CustomerRepository'den Customer'ı çekip sonra Cart'ı bulmanız gerekebilir.
        // Örn: return cartRepository.findByCustomer(customer); (Bu metodu CartRepository'de tanımlamanız gerekir)
        return cartRepository.findByCustomer(customer); // Bu metodu CartRepository'ye eklemeyi unutmayın
    }

    @Override
    @Transactional // Birden fazla veritabanı işlemi olabileceği için @Transactional kullanmak iyi bir pratik
    public Cart addProductToCart(Long cartId, Long productId, int quantity) {
        Cart cart = cartRepository.findById(cartId)
                .orElseThrow(() -> new RuntimeException("Cart not found with id: " + cartId));
        Product product = productRepository.findById(productId)
                .orElseThrow(() -> new RuntimeException("Product not found with id: " + productId));

        // Ürünün stok kontrolü
        if (product.getStock() < quantity) {
            throw new RuntimeException("Not enough stock for product: " + product.getName());
        }

        // Sepette ürün zaten varsa miktarını güncelle, yoksa yeni CartItem oluştur
        Optional<CartItem> existingCartItem = cart.getCartItems().stream()
                .filter(item -> item.getProduct().getId().equals(productId))
                .findFirst();

        if (existingCartItem.isPresent()) {
            CartItem item = existingCartItem.get();
            item.setQuantity(item.getQuantity() + quantity);
            // item.setPriceAtPurchase(product.getPrice()); // Ürünün anlık fiyatını da kaydedebilirsiniz
        } else {
            // Yeni CartItem oluşturma mantığı (CartItem'ınızın yapısına göre değişir)
            // CartItem'ın bir constructor'ı olmalı veya setter metodları kullanılmalı
            CartItem newItem = new CartItem();
            newItem.setCart(cart);
            newItem.setProduct(product);
            newItem.setQuantity(quantity);
            newItem.setPriceAtPurchase(product.getPrice()); // Ürünün anlık fiyatını kaydet
            cart.getCartItems().add(newItem);
        }

        // Stoktan düşme
        product.setStock(product.getStock() - quantity);
        productRepository.save(product); // Ürün stokunu güncelle

        // Sepetin toplam fiyatını güncelle
        // cart.setTotalPrice(calculateTotalPrice(cart)); // calculateTotalPrice metodunu implement etmelisiniz

        return cartRepository.save(cart);
    }


    @Override
    @Transactional
    public Cart removeProductFromCart(Long cartId, Long productId) {
        Cart cart = cartRepository.findById(cartId)
                .orElseThrow(() -> new RuntimeException("Cart not found with id: " + cartId));
        Product product = productRepository.findById(productId)
                .orElseThrow(() -> new RuntimeException("Product not found with id: " + productId));

        Optional<CartItem> itemToRemove = cart.getCartItems().stream()
                .filter(item -> item.getProduct().getId().equals(productId))
                .findFirst();

        if (itemToRemove.isPresent()) {
            CartItem cartItem = itemToRemove.get();
            cart.getCartItems().remove(cartItem); // Sepet öğesini listeden çıkar

            // Ürünün stokunu geri ekle
            product.setStock(product.getStock() + cartItem.getQuantity());
            productRepository.save(product);

            // Sepetin toplam fiyatını güncelle
            // cart.setTotalPrice(calculateTotalPrice(cart));
        } else {
            throw new RuntimeException("Product not found in cart: " + productId);
        }

        return cartRepository.save(cart);
    }

    @Override
    @Transactional
    public Cart emptyCart(Long cartId) {
        Cart cart = cartRepository.findById(cartId)
                .orElseThrow(() -> new RuntimeException("Cart not found with id: " + cartId));

        // Sepetteki ürünlerin stoklarını geri ekle
        for (CartItem item : cart.getCartItems()) {
            Product product = item.getProduct();
            if (product != null) {
                product.setStock(product.getStock() + item.getQuantity());
                productRepository.save(product);
            }
        }

        cart.getCartItems().clear(); // Sepet öğelerini temizle
        cart.setTotalPrice(0.0); // Toplam fiyatı sıfırla
        return cartRepository.save(cart);
    }

    // Sepetin toplam fiyatını hesaplayan yardımcı metot
    private double calculateTotalPrice(Cart cart) {
        return cart.getCartItems().stream()
                .mapToDouble(item -> item.getQuantity() * item.getPriceAtPurchase()) // CartItem'da priceAtPurchase olmalı
                .sum();
    }
}